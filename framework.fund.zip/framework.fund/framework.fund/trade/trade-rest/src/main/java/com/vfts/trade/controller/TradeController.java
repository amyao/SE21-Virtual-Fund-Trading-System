package com.vfts.trade.controller;


import com.vfts.user.entity.UserEntity;
import com.vfts.user.entity.QuestionEntity;
import com.vfts.user.iface.IUserService;
import com.vfts.trade.entity.AccountEntity;
import com.vfts.trade.entity.HoldingEntity;
import com.vfts.trade.entity.OrderEntity;
import com.vfts.trade.entity.TradeEntity;
import com.vfts.trade.iface.IOrderService;
import com.vfts.trade.iface.ITradeService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.Arrays;
import java.util.Date;
import java.util.SimpleDateFormat;

@Slf4j
@RestController
@RequestMapping(value = "/uiapi/user")
public class TradeController {

    @Autowired
    private ITradeService tradeService;
    private IOrderService orderService;
    private IUserService userService;
    private HttpClient httpClient;

    //1. Display Account Home Info
    //展示所有AccountEntity拥有的properties
    //return: dictionary = {uuid:xxx, accountBalance:xxx, ...}
    /**
     * 展示账户中心
     * @param uuid
     * @return String (JSON)
     */
    @RequestMapping(value = "/accountHome",method = RequestMethod.POST)
    @ApiOperation(value = "账户中心", httpMethod = "POST")
    public String displayAccountHome(@RequestParam String uuid){
        String accountBalanceStr = String.valueOf(tradeService.getBalanceByUuid(uuid));
        String yesterdayYieldStr = String.valueOf(tradeService.getYesterdayYieldByUuid(uuid));
        String holdingYieldStr = String.valueOf(tradeService.getHoldingsYieldByUuid(uuid));
        String totalYieldStr = String.valueOf(tradeService.getTotalYieldByUuid(uuid));
        List<Integer> selfListed = tradeService.listSelfListedByUuid(uuid);//array of fundId
        //convert to String
        String selfListedStr = "[";
        for (int i = 0; i < selfListed.size(); i ++){
            selfListedStr.append(String.valueOf(selfListed[i]));
            if (i != selfListed.size() - 1){
                selfListedStr.append(", ");
            }
            else{
                selfListedStr.append("]");
            }
        }

        List<HoldingEntity> currentHoldings = tradeService.listCurrentHoldingsByUuid(uuid);
        String currentHoldingsStr = "[";//"[{oneHolding}, {oneHolding}, ..., {oneHolding}]"
        String oneHoldingStr;//to be appended to currentHoldingStr in a loop
        HoldingEntity oneHolding;
        for (int i = 0; i < currentHoldings.size(); i ++){
            oneHolding = currentHoldings[i];
            String fundIdStr = String.valueOf(oneHolding.getFundId());
            String holdingSharesStr = String.valueOf(oneHolding.getHoldingShares());
            String startHoldingDateStr = oneHolding.getStartHoldingDate();
            String totalYieldStr = String.valueOf(oneHolding.getTotalYield());
            String yieldHistoryStr;
            double[] yieldHistory = oneHolding.getYieldHistory;
            //formatting yieldHistoryStr
            for (int j = 0; j < yieldHistory.length; j ++) {
                if (j != yieldHistory.length - 1) {
                    yieldHistoryStr.append(String.valueOf(yieldHistory[j] + ", "));
                } else {
                    yieldHistoryStr.append(String.valueOf(yieldHistory[j]));
                }
            }
            oneHoldingStr = "{uuid: "+uuid+", "
                           +"fundId: "+fundIdStr+", "
                           +"holdingShares: "+holdingSharesStr+", "
                           +"startHoldingDate: "+startHoldingDateStr+", "
                           +"totalYield: "+totalYieldStr+", "
                           +"yieldHistory: ["+yieldHistoryStr+"]}";
            currentHoldingsStr.append(oneHoldingStr);
            if (i != currentHoldings.size() - 1){
                currentHoldingsStr.append(", ");
            }
            else{
                currentHoldingsStr.append("]");
            }
        }//end of building the currentHoldingsStr

        List<OrderEntity> orderHistory = tradeService.listOrderHistory(uuid);
        String orderHistoryStr = "[";//"[{oneOrder}, {oneOrder}, ..., {oneOrder}]"
        String oneOrderStr;
        OrderEntity oneOrder;
        for (int i = 0; i < orderHistory.size(); i ++){
            oneOrder = orderHistory[i];
            String orderIdStr = oneOrder.getOrderId();
            String fundIdStr = String.valueOf(oneOrder.getFundId());
            String orderTypeStr = String.valueOf(oneOrder.getOrderType());
            String sellingSharesStr = String.valueOf(oneOrder.getSellingShares());
            String buyingAmountStr = String.valueOf(oneOrder.getBuyingAmount());
            String orderDateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(oneOrder.getOrderDate());
            String orderStatusStr = oneOrder.getOrderStatus();

            oneOrderStr = "{uuid: "+uuid+", "
                         +"orderId: "+orderIdStr+", "
                         +"fundId: "+fundIdStr+", "
                         +"orderType: "+orderTypeStr+", "
                         +"sellingShares: "+sellingSharesStr+", "
                         +"buyingAmount: "+buyingAmountStr+", "
                         +"orderDate: "+orderDateStr+", "
                         +"orderStatus: "+orderStatusStr+"}";

            orderHistoryStr.append(oneOrderStr);
            if (i != orderHistory.size() - 1){
                orderHistoryStr.append(", ");
            }
            else{
                orderHistoryStr.append("]");
            }
        }//end of building the orderHistoryStr

        //compose the entire string
        String accountEntityStr = "{uuid: " +uuid+", "
                                 +"accountBalance: "+accountBalanceStr+", "
                                 +"yesterdayYield: "+yesterdayYieldStr+", "
                                 +"holdingYield: "+holdingYieldStr+", "
                                 +"totalYield: "+totalYieldStr+", "
                                 +"selfListed: "+selfListedStr+", "
                                 +"currentHoldings: "+currentHoldingsStr+", "
                                 +"orderHistory: "+orderHistoryStr+"}";

        return accountEntityStr;
    }

    //2. Buy
    //params: uuid, fundId, amount of money, payPwd
    //** checkPayPwd is an external function (**TODO)
    /**
     * 买入订单(orderType = 0)
     * @param uuid, fundId, buyingAmount, payPwd
     * @return String
     */
    @RequestMapping(value = "/buyOrder",method = RequestMethod.POST)
    @ApiOperation(value = "买入订单", httpMethod = "POST")
    public String buy(@RequestParam String uuid, int fundId, double buyingAmount, String payPwd){
        //OrderEntity(String uuid, int fundId, int orderType, double sellingShares, double buyingAmount)
        int payPwdMatches = userService.checkPayPwd(uuid, payPwd);
        if (payPwdMatches) {
            OrderEntity newOrder = new OrderEntity(uuid, fundId, 0, 0, buyingAmount);
            orderService.createOrder(newOrder);
            AccountEntity thisAccount = orderService.getAccountByUuid(uuid);
            thisAccount.insertOrder(newOrder);
            return "Order placed:to buy fund " + String.valueOf(fundId) + " for " + String.valueOf(buyingAmount) + " yuan.";
        }
        else{
            return "Failed to place an order to buy: Wrong payment password.";
        }
    }

    //3. Sell
    //params: uuid, fundId, num of shared, payPwd
    //** checkPayPwd is an external function (**TODO)
    /**
     * 卖出订单(orderType = 1)
     * @param uuid, fundId, sellingShares, payPwd
     * @return String
     */
    @RequestMapping(value = "/sellOrder",method = RequestMethod.POST)
    @ApiOperation(value = "卖出订单", httpMethod = "POST")
    public String buy(@RequestParam String uuid, int fundId, double sellingShares, String payPwd){
        //Constructor: OrderEntity(String uuid, int fundId, int orderType, double sellingShares, double buyingAmount)
        int payPwdMatches = userService.checkPayPwd(uuid, payPwd);
        if (payPwdMatches) {
            OrderEntity newOrder = new OrderEntity(uuid, fundId, 1, sellingShares, 0);
            orderService.createOrder(newOrder);
            AccountEntity thisAccount = orderService.getAccountByUuid(uuid);
            thisAccount.insertOrder(newOrder);
            return "Order placed: to sell fund " + String.valueOf(fundId) + " for " + String.valueOf(sellingShares) + " shares.";
        }
        else{
            return "Failed to place an order to sell: Wrong payment password.";
        }
    }

    //4. Add to SelfListed
    // params: String uuid, int fundId
    @RequestMapping(value = "/addToSelfListed", method = RequestMethod.POST)
    @ApiOperation(value = "加入自选", httpMethod = "POST")
    public String addToSelfListed(@RequestParam String uuid, int fundId){
        AccountEntity thisAccount = orderService.getAccountByUuid(uuid);
        if (thisAccount != null) {
            thisAccount.insertSelfListed(Integer.valueOf(fundId));
            return "Fund "+String.valueOf(fundId)+" succesfully added to self-listed.";
        }
        else{
            return "Failed to add fund "+String.valueOf(fundId)+" to self-listed.";
        }
    }

    //5. Delete from SelfListed
    // params: String uuid, int fundId
    @RequestMapping(value = "/deleteFromSelfListed", method = RequestMethod.POST)
    @ApiOperation(value = "删除自选", httpMethod = "POST")
    public String deleteFromSelfListed(@RequestParam String uuid, int fundId){
        AccountEntity thisAccount = orderService.getAccountByUuid(uuid);
        if (thisAccount != null) {
            thisAccount.deleteSelfListed(Integer.valueOf(fundId));
            return "Fund "+String.valueOf(fundId)+" succesfully deleted from self-listed.";
        }
        else{
            return "Failed to delete fund "+String.valueOf(fundId)+" from self-listed.";
        }
    }

    //6. updateOrderToTrade
    //params: oredrId
    @RequestMapping(value = "/updateOrderToTrade", method = RequestMethod.POST)
    @ApiOperation(value = "订单转交易", httpMethod = "POST")
    public int updateOrderToTrade(@RequestParam OrderEntity thisOrder){
        //Constructor: TradeEntity(String uuid, String orderId, int fundId, double tradePrice, int orderType, double buyingAmount, double sellingShares, Date orderDate)
        int orderType = thisOrder.getOrderType();
        String url = "https://api.doctorxiong.club/v1/fund?code="+fundId+"&token=39CknoZcrT";
        HttpMethod method = HttpMethod.GET;
        String JSONStr = httpClient.client(url, method);
        //find "netWorth":2.0156 in JSONStr
        int startIndex = JSONStr.indexOf("netWorth\":") + 10;
        int endIndex = JSONStr.indexOf(",\"dayGrowth\":") - 1;
        String netWorthStr = JSONStr.substring(startIndex, endIndex);
        double tradePrice = Double.parseDouble(netWorthStr);

        if (orderType == 0){//buying order
            TradeEntity newTrade = new TradeEntity(uuid, thisOrder.getOrderId(), thisOrder.getFundId(), tradePrice, 0, thisOrder.getBuyingAmount(), 0, thisOrder.getOrderDate());
            tradeService.createTrade(newTrade);//add a new record to DB of this trade
            //update the record in currentHoldings of the Account accordingly
            AccountEntity thisAccount = orderService.getAccountByUuid(uuid);
            List<HoldingEntity> currentHoldings = thisAccount.getCurrentHoldings();
            for (int i = 0; i < currentHoldings.size(); i ++){
                if (currentHoldings[i].getFundId() == fundId){
                    //found matching holding record
                    double newHoldingShares = currentHoldings[i].getHoldingShares() + newTrade.getTradeShare();
                    currentHoldings[i].setHoldingShares(newHoldingShares);
                    break;
                }
                if (i == currentHoldings.size() - 1){//no matching holding found-> insert new holding record
                    //Constructor: HoldingEntity(String uuid, int fundId, double holdingShares, String startHoldingDate)
                    HoldingEntity newHoldingRecord = new HoldingEntity(uuid, fundId, newTrade.getTradeShares(), newTrade.getTradeDate());
                    currentHoldings.add(newHoldingRecord);
                }
            }
            thisAccount.setCurrentHoldings(currentHoldings);
            //update accountBalance
            double newBalance = thisAccount.getAccountBalance() - thisOrder.getBuyingAmount();
            thisAccount.setAccountBalance(newBalance);
        }
        else{//selling order
            TradeEntity newTrade = new TradeEntity(uuid, thisOrder.getOrderId(), thisOrder.getFundId(), tradePrice, 1, 0, thisOrder.getSellingShares(), thisOrder.getOrderDate());
            tradeService.createTrade(newTrade);//add a new record to DB of this trade
            //update the record in currentHoldings of teh Account accordingly
            AccountEntity thisAccount = orderService.getAccountByUuid(uuid);
            List<HoldingEntity> currentHoldings = thisAccount.getCurrentHoldings();
            for (int i = 0; i < currentHoldings.size(); i ++) {
                if (currentHoldings[i].getFundId() == fundId) {
                    //found matching holding record
                    double newHoldingShares = currentHoldings[i].getHoldingShares() - newTrade.getTradeShare();
                    currentHoldings[i].setHoldingShares(newHoldingShares);
                    break;
                }
            }
            thisAccount.setCurrentHoldings(currentHoldings);
            //update accountBalance
            double newBalance = thisAccount.getAccountBalance() + thisOrder.getSellingShares() * newTrade.getTradePrice();
            thisAccount.setAccountBalance(newBalance);
        }
    }




}