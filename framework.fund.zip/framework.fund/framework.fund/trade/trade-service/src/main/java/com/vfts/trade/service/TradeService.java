package com.vfts.trade.service;

import com.vfts.trade.dao.ITradeMapper;
import com.vfts.trade.entity.AccountEntity;
import com.vfts.trade.entity.HoldingEntity;
import com.vfts.trade.entity.OrderEntity;
import com.vfts.trade.entity.TradeEntity;
import com.vfts.trade.iface.IOrderService;
import com.vfts.trade.iface.ITradeService;

public class TradeService implements ITradeService {

    @Autowired
    private ITradeMapper tradeMapper;

    /* list out all funds that the user currently holds */
    @Override
    public List<Holding> listCurrentHoldingsByUuid(String uuid){
        return tradeMapper.listCurrentHoldingsByUuid(uuid);
    }

    /* list out order history */
    @Override
    public List<OrderEntity> listOrderHistory(String uuid){//return orderHistory in Account by uuid
        return tradeMapper.listOrderHistory(uuid);
    }

    /* return the balance of the user*/
    @Override
    public double getBalanceByUuid(String uuid){
        return tradeMapper.getBalanceByUuid(uuid);
    }

    /* return the yield of yesterday*/
    @Override
    public double getYesterdayYieldByUuid(String uuid){
        return tradeMapper.getYesterdayYieldByUuid(uuid);
    }

    /* return the yield since holding the current funds*/
    @Override
    public double getHoldingsYieldByUuid(String uuid){
        return tradeMapper.getHoldingYieldByUuid(uuid);
    }

    /* return the total yield since initial*/
    @Override
    public double getTotalYieldByUuid(String uuid){
        return tradeMapper.getTotalYieldByUuid(uuid);
    }

    /* list out all the SelfListed funds*/
    @Override
    public int[] listSelfListedByUuid(String uuid){
        return tradeMapper.listSelfListedByUuid(uuid);
    }

    /* create a trade record */
    @Override
    void createTrade(TradeEntity tradeEntity){
        tradeMapper.createTrade(tradeEntity);
    }

/*    *//* List of the history of yields of user's current holding funds *//*
    @Override
    public void getYieldHistoryByUuid(String uuid){
        tradeMapper.getYieldHistoryByUuid(uuid);
    }*/
}