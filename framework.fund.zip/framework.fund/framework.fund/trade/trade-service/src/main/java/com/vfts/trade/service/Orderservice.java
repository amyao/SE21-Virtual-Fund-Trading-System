package com.vfts.trade.service;

import com.vfts.trade.dao.ITradeMapper;
import com.vfts.trade.entity.AccountEntity;
import com.vfts.trade.entity.HoldingEntity;
import com.vfts.trade.entity.OrderEntity;
import com.vfts.trade.entity.TradeEntity;
import com.vfts.trade.iface.IOrderService;
import com.vfts.trade.iface.ITradeService;

public class OrderService implements IOrderService {

    @Autowired
    private IOrderMapper orderMapper;

    /* create a new order to buy or sell fund */
    @Override
    void createOrder(OrderEntity orderEntity){
        orderMapper.createOrder(orderEntity);
    }

    /* withdraw the buy/sell order that previously created */
    /* If withdrawal is successful, return 0; otherwise, return 1 */
    @Override
    int withdrawOrder(String orderId){
        return orderMapper.withdrawOrder(orderId);
    }

    /* list out order history */
    @Override
    List<OrderEntity> listOrderHistory(String uuid){//return orderHistory in Account by uuid
        return orderMapper.listOrderHistory(uuid);
    }

    /* get account entity by uuid */
    @Override
    AccountEntity getAccountByUuid(String uuid){
        return orderMapper.getAccountByUuid(uuid);
    };

}
