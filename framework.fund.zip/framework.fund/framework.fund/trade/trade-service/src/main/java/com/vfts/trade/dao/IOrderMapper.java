package com.vfts.trade.dao;

/*import com.qianxin.ids.idam.bizcomps.user.api.entity.BizUserEntity;
import com.qianxin.ids.idam.sdk.view.QueryParam;*/
import com.vfts.trade.entity.AccountEntity;
import com.vfts.trade.entity.HoldingEntity;
import com.vfts.trade.entity.OrderEntity;
import com.vfts.trade.entity.TradeEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Set;

@Mapper
public interface IOrderMapper {
    /* create a new order to buy or sell fund */
    void createOrder(OrderEntity OrderEntity);

    /* withdraw the buy/sell order that previously created */
    /* If withdrawal is successful, return 0; otherwise, return 1 */
    int withdrawOrder(String orderId);

    /* list out order history */
    List<OrderEntity> listOrderHistory(String uuid);//return orderHistory in Account by uuid

    /* get account entity by uuid */
    AccountEntity getAccountByUuid(String uuid);
}