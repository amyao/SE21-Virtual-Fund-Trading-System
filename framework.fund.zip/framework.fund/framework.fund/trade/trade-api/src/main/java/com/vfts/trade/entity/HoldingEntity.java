package com.vfts.trade.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.*

@Data
@AllArgsConstructor
@NoArgsConstructor

public class HoldingEntity {
    private String uuid;
    private int fundId;
    private double holdingShares;
    private String startHoldingDate;
    private double totalYield = 0;//default set to 0
    private List<Double> yieldHistory = new ArrayList<Double>;

    public HoldingEntity(String uuid, int fundId, double holdingShares, String startHoldingDate) {
        this.uuid = uuid;
        this.fundId = fundId;
        this.holdingShares = holdingShares;
        this.startHoldingDate = startHoldingDate;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public int getFundId() {
        return fundId;
    }

    public void setFundId(int fundId) {
        this.fundId = fundId;
    }

    public double getHoldingShares() {
        return holdingShares;
    }

    public void setHoldingShares(double holdingShares) {
        this.holdingShares = holdingShares;
    }

    public String getStartHoldingDate() {
        return startHoldingDate;
    }

    public void setStartHoldingDate(String startHoldingDate) {
        this.startHoldingDate = startHoldingDate;
    }

    public double getTotalYield() {
        return totalYield;
    }

    public void setTotalYield(double totalYield) {
        this.totalYield = totalYield;
    }

    public void inserYieldHistory(Double newYield){
        this.yieldHistory.add(newYield);
    }

    public List<Double> getYieldHistory() {
        return yieldHistory;
    }

    public void setYieldHistory(List<Double> yieldHistory) {
        this.yieldHistory = yieldHistory;
    }
}
