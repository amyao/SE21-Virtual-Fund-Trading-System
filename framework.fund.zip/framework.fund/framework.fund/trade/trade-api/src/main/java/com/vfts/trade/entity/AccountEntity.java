package com.vfts.trade.entity;
import com.vfts.trade.entity.HoldingEntity;
import java.util;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class AccountEntity {
    private String uuid;
    private double accountBalance;
    private double yesterdayYield = 0;
    private double holdingYield = 0;
    private double totalYield = 0;
    private List<Integer> selfListed;
    private List<HoldingEntity> currentHoldings;
    private List<OrderEntity> orderHistory;

    public AccountEntity(String uuid, double accountBalance) {
        this.uuid = uuid;
        this.accountBalance = accountBalance;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public double getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    public double getYesterdayYield() {
        return yesterdayYield;
    }

    public void setYesterdayYield(double yesterdayYield) {
        this.yesterdayYield = yesterdayYield;
    }

    public double getHoldingYield() {
        return holdingYield;
    }

    public void setHoldingYield(double holdingYield) {
        this.holdingYield = holdingYield;
    }

    public double getTotalYield() {
        return totalYield;
    }

    public void setTotalYield(double totalYield) {
        this.totalYield = totalYield;
    }

    public void insertSelfListed(Integer fundId){
        this.selfListed.add(fundId);
    }

    public void deleteSelfListed(Integer fundId){
        this.selfListed.remove(fundId);
    }

    public List<Integer> getSelfListed() {
        return selfListed;
    }

    public void setSelfListed(List<Integer> selfListed) {
        this.selfListed = selfListed;
    }

    public void insertHolding(HoldingEntity newHolding){
        this.currentHoldings.add(newHolding);
    }

    public void insertOrder(OredrEntity newOrder){
        this.orderHistory.add(newOrder);
    }

    public List<HoldingEntity> getCurrentHoldings() {
        return currentHoldings;
    }

    public List<OrderEntity> getOrderHistory() {
        return orderHistory;
    }

    public void setCurrentHoldings(List<HoldingEntity> currentHoldings) {
        this.currentHoldings = currentHoldings;
    }

    public void setOrderHistory(List<OrderEntity> orderHistory) {
        this.orderHistory = orderHistory;
    }
}
