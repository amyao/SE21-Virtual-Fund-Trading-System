package com.vfts.trade.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class OrderEntity {
    private String uuid;
    private String orderId;
    private int fundId;
    private int orderType; //0:buy, 1:sell
    /* Only one of the two following two properties is used for one order:
    e.g. If the order is of type 0:buy,
    buyingAmount is to be used and sellingShares is set to 0 */
    private double sellingShares;
    private double buyingAmount;
    private Date orderDate;//generated upon order creation
                            //yyyy-MM-dd HH:mm:ss
    /* orderStatus is in {"processing", "success", "withdrawn"} */
    private String orderStatus = "processing";//default set to "processing"

    public OrderEntity(String uuid, int fundId, int orderType, double sellingShares, double buyingAmount) {
        this.uuid = uuid;
        this.orderId = UUID.randomUUID().toString();
        this.fundId = fundId;
        this.orderType = orderType;
        this.sellingShares = sellingShares;
        this.buyingAmount = buyingAmount;
        this.orderDate = new Date();//gets current date and time
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public int getFundId() {
        return fundId;
    }

    public void setFundId(int fundId) {
        this.fundId = fundId;
    }

    public int getOrderType() {
        return orderType;
    }

    public void setOrderType(int orderType) {
        this.orderType = orderType;
    }

    public double getSellingShares() {
        return sellingShares;
    }

    public void setSellingShares(double sellingShares) {
        this.sellingShares = sellingShares;
    }

    public double getBuyingAmount() {
        return buyingAmount;
    }

    public void setBuyingAmount(double buyingAmount) {
        this.buyingAmount = buyingAmount;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }
}
