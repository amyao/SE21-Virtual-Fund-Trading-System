package com.vfts.trade.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class TradeEntity {
    private String uuid;
    private String orderId;
    private int fundId;
    private int tradeType; //0:buy, 1:sell
    private double tradeShares;
    private double tradePrice;
    private Date orderDate;
    private Date tradeDate;

    public TradeEntity(String uuid, String orderId, int fundId, double tradePrice, int orderType, double buyingAmount, double sellingShares, Date orderDate) {
        this.uuid = uuid;
        this.orderId = orderId;
        this.fundId = fundId;
        this.tradePrice = tradePrice;
        this.tradeType = orderType;
        if (tradeType == 0){//buying
            this.tradeShares = buyingAmount / tradePrice;
        }
        else{//selling
            this.tradeShares = sellingShares;
        }
        this.orderDate = orderDate;
        this.tradeDate = new Date();//gets current date and time
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public int getFundId() {
        return fundId;
    }

    public void setFundId(int fundId) {
        this.fundId = fundId;
    }

    public int getTradeType() {
        return tradeType;
    }

    public void setTradeType(int tradeType) {
        this.tradeType = tradeType;
    }

    public double getTradeShares() {
        return tradeShares;
    }

    public void setTradeShares(double tradeShares) {
        this.tradeShares = tradeShares;
    }

    public double getTradePrice() {
        return tradePrice;
    }

    public void setTradePrice(double tradePrice) {
        this.tradePrice = tradePrice;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public Date getTradeDate() {
        return tradeDate;
    }

    public void setTradeDate(Date tradeDate) {
        this.tradeDate = tradeDate;
    }
}
