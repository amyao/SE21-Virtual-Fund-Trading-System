package com.vfts.trade.iface;

import com.vfts.trade.entity.AccountEntity;
import com.vfts.trade.entity.OrderEntity;
import com.vfts.trade.entity.HoldingEntity;

import java.util.List;

public interface ITradeService {
    /* list out all funds that the user currently holds */
    List<HoldingEntity> listCurrentHoldingsByUuid(String uuid);//return currentHoldings in Account by uuid

    /* list out order history */
    List<OrderEntity> listOrderHistory(String uuid);//return orderHistory in Account by uuid

    /* return the balance of the user*/
    double getBalanceByUuid(String uuid);

    /* return the yield of yesterday*/
    double getYesterdayYieldByUuid(String uuid);

    /* return the yield since holding the current funds*/
    double getHoldingsYieldByUuid(String uuid);

    /* return the total yield since initial*/
    double getTotalYieldByUuid(String uuid);

    /* list out all the SelfListed funds*/
    List<Integer> listSelfListedByUuid(String uuid);//return selfListed in Account by uuid

    /* create a trade record */
    void createTrade(TradeEntity tradeEntity);

    /* List of the history of yields of user's current holding funds */
    //void getYieldHistoryByUuid(String uuid);
}

