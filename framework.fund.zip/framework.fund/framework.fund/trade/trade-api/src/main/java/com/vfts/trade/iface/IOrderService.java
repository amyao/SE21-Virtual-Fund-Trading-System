package com.vfts.trade.iface;

import com.vfts.trade.entity.OrderEntity;
import com.vfts.trade.entity.HoldingEntity;
import com.vfts.trade.entity.TradeEntity;
import com.vfts.trade.entity.AccountEntity;

public interface IOrderService {
    /* create a new order to buy or sell fund */
    void createOrder(OrderEntity OrderEntity);

    /* withdraw the buy/sell order that previously created */
    /* If withdrawal is successful, return 0; otherwise, return 1 */
    int withdrawOrder(String orderId);

    /* list out order history */
    List<OrderEntity> listOrderHistory(String uuid);//return orderHistory in Account by uuid

    /* get account entity by uuid */
    AccountEntity getAccountByUuid(String uuid);

/*    *//* apply to increase the balance *//*
    void increaseBalanceApp(String uuid, double amount);*/
}
