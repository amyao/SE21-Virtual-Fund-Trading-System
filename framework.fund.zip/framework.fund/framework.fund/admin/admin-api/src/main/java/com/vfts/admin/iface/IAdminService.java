package com.vfts.admin.iface;

public interface IAdminService {
    /* admit the order to be processed */
    void processOrder(String orderId);

    /* admit to increase the balance of a user account */
    void processIncreaseBalanceApp(String userId, double amount);

    /* list all users */
    void listUsers();
}
