package com.vfts.user.controller;


import com.vfts.user.entity.UserEntity;
import com.vfts.user.entity.QuestionEntity;
import com.vfts.user.iface.IUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@Slf4j
@RestController
@RequestMapping(value = "/uiapi/user")
public class UserController {

    @Autowired
    private IUserService userService;

//    10.0.0.1:19888/uiapi/user/add  -> url
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    @ApiOperation(value = "添加用户", httpMethod = "POST")
    public void createUser(@RequestBody UserEntity userEntity){
        try {
            log.info("add user....");
//            调用后端服务， 添加用户
            userService.createUser(userEntity);
        } catch (Exception e) {
//            TODO: 封装异常类
        }
        log.info(".....");
    }

    /**
     * 登陆方法, 用户输入邮箱和密码, 查询数据库检验是否有该账户,如果有,
     * 返回原先页面 ,登陆成功。
     * @param username 用户名
     * @param password 用户密码
     * @return uuid
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    @ApiOperation(value = "登陆", httpMethod = "POST")
    public String login(@RequestParam String username, @RequestParam String pwd) {
        UserEntity thisUser = userService.getUserByUsername(username);
        // 如果数据库中未查到该账号:
        if (thisUser == null) {
            log.warn("attempting to log in with the non-existed account");
            return "用户名不存在";
        }
        else {
            if (thisUser.getPwd().equals(pwd)) {
                // 如果密码与用户名配对成功
                log.warn(user.toString()+ " logged in");
                return username+"登陆成功";
            }
            else {
                // 如果密码与用户名不匹配
                log.warn(user.toString()+ " failed to log in");
                return "密码错误";
            }
        }
    }

    /**
     * 注册方法, 用户输入用户名、密码、支付密码、安全问题, 查询数据库检验是否有该账户,如果有,
     * 返回原先页面，显示用户名已存在，重新注册；如果没有，注册成功，返回原先页面，进行登录
     * @param username 用户名
     * @param password 用户密码
     *
     * @return uuid
     */
    @RequestMapping(value = "/register",method = RequestMethod.POST)
    @ApiOperation(value = "注册", httpMethod = "POST")
    public void registerUser(@RequestParam String username, @RequestParam String pwd, @RequestParam String userPayPwd,
                             @RequestParam int questionIndex, @RequestParam String answer){
        UserEntity thisUser = userService.getUserByUsernameAndPwd(username, pwd);
        // 如果数据库中已有该用户名
        if (thisUser != null) {
            log.warn("Username already existed, please choose another one.");
            return "用户名已存在";
        }
        // 如果数据库中没有该用户名，可新建用户
        else {
            UUID uuid = UUID.randomUUID();
            String _uuid = uuid.toString();
            UserEntity newUser = new UserEntity(_uuid, username, pwd, userPayPwd);
            userService.createUser(newUser);
            QuestionEntity newQuestionPair = new QuestionEntity(questionIndex, answer);
            userService.updateSecurityQuestion(_uuid, newQuestionPair);
            log.warn(newUser.toString()+ "registered successfully");
            return userneme+"注册成功";
        }
    }

    @RequestMapping(value = "/updateUser", method = RequestMethod.POST)
    @ApiOperation(value = "更新用户", httpMethod = "POST")
    public void

    /**
     * 更新账户密码
     */
    @RequestMapping(value = "/updatePwd", method = RequestMethod.POST)
    @ApiOperation(value = "更新账户密码", httpMethod = "POST")
    public String updatePwd(@RequestParam String username, @RequestParam String newPwd){
        UserEntity thisUser = userService.getUserByUsername(username);
        // 如果数据库中未查到该账号:
        if (thisUser == null) {
            log.warn("attempting to log in with the non-existed account");
            return "用户名不存在";
        }
        else {
            thisUser.setPwd(newPwd);
            userService.updatePwd(thisUser);
            log.warn(thisUser.toString()+ "change password successfully");
            return userneme+"更新账户密码成功";
        }
    }

    /**
     * 更新支付密码
     */
    @RequestMapping(value = "/updatePayPwd", method = RequestMethod.POST)
    @ApiOperation(value = "更新支付密码", httpMethod = "POST")
    public String updatePwd(@RequestParam String username, @RequestParam String newPayPwd){
        UserEntity thisUser = userService.getUserByUsername(username);
        // 如果数据库中未查到该账号:
        if (thisUser == null) {
            log.warn("attempting to log in with the non-existed account");
            return "用户名不存在";
        }
        else {
            thisUser.setPayPwd(newPayPwd);
            userService.updatePayPwd(thisUser);
            log.warn(thisUser.toString()+ "change pay password successfully");
            return userneme+"更新支付密码成功";
        }
    }

    /**
     * 更新安全问题
     */
    @RequestMapping(value = "/updateQuestion", method = RequestMethod.POST)
    @ApiOperation(value = "更新安全问题", httpMethod = "POST")
    public String updatePwd(@RequestParam String username, @RequestParam int questionIndex, @RequestParam String answer){
        UserEntity thisUser = userService.getUserByUsername(username);
        // 如果数据库中未查到该账号:
        if (thisUser == null) {
            log.warn("attempting to log in with the non-existed account");
            return "用户名不存在";
        }
        else {
            QuestionEntity newQuestionPair = new QuestionEntity(questionIndex, answer);
            userService.updateSecurityQuestion(thisUser.getId(), newQuestionPair);
            log.warn(thisUser.toString()+ "change question successfully");
            return userneme+"更新安全问题成功";
        }
    }

    /**
     * 查看所有用户的注册信息，按照Spring Boot的设定，以Json的形式输送给用户端。
     * @return
     */
    @RequestMapping(value="/all", method = ReqeustMethod.POST)
    @ApiOperation(value = "全部", httpMethod = "POST")
    public @ResponseBody List<UserEntity> listAllUsers() {
        return userService.listAllUsers();
    }

}
