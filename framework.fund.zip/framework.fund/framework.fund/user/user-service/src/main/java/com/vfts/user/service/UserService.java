package com.vfts.user.service;

import com.vfts.user.dao.IUserMapper;
import com.vfts.user.entity.UserEntity;
import com.vfts.user.iface.IUserService;
import com.vfts.trade.iface.ITradeService;

public class UserService implements IUserService {
    @Autowired
    private IUserMapper userMapper;
    @Autowired
    private ITradeService tradeService;

    @Override
    public void createUser(UserEntity userEntity) {
        userMapper.createUser(userEntity);
    }

    @Override
    public String updatePwd(UserEntity userEntity) {
        userMapper.updatePwd(userEntity);
    }

    @Override
    public String updatePayPwd(UserEntity userEntity) {
        userMapper.updatePayPwd(userEntity);
    }

/*    @Override
    public void deleteUser(String uuid) {
        userMapper.deleteUser(uuid);
//        TODO: 同步删除用户相关订单交易信息
//        tradeService.deleteByXXX();
    }*/

    @Override
    public UserEntity getUserByUuid(String uuid) {
        return userMapper.getUserByUuid(uuid);
    }

    @Override
    public UserEntity getUserByUsername(String username) {
        return userMapper.getUserByUsername(username);
    }

    @Override
    public String updateSecurityQuestion(String uuid, QuestionEntity questionPair){
        userMapper.updateSecurityQuestion(uuid, questionPair);
    }

    @Override
    public List<UserEntity> listAllUsers() {
        return userMapper.listAllUsers();
    }

    /* Verify the Payment Pwd for userId */
    /* If input matches record, return 1; otherwise, return 0 */
    @Override
    int checkPayPwd(String uuid, String payPwd){
        return userMapper.checkPayPwd(uuid, payPwd);
    }
}
