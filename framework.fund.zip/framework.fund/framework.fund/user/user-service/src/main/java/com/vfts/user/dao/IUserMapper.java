package com.vfts.user.dao;

/*import com.qianxin.ids.idam.bizcomps.user.api.entity.BizUserEntity;
import com.qianxin.ids.idam.sdk.view.QueryParam;*/
import com.vfts.user.entity.UserEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Set;

@Mapper
public interface IUserMapper {
	void createUser(UserEntity userEntity);

	String updatePwd(UserEntity userEntity);

	String updatepPayPwd(UserEntity userEntity);

	void deleteUser(String userId);

	UserEntity getUserById(String uuid);

	UserEntity getUserByUsernameAndPwd(String username, String pwd);

	List<UserEntity> listAllUsers();

	String updateSecurityQuestion(String uuid, QuestionEntity questionPair);

	/* Verify the Payment Pwd for userId */
	/* If input matches record, return 0; otherwise, return 1 */
	int checkPayPwd(String uuid, String payPwd);
}
