CREATE TABLE If Not Exists `FRAMEWORK_USER` (
  `uuid` varchar(64) NOT NULL  COMMENT '主键id',
  `userName` varchar(128) COMMENT '用户名',
  `pwd` varchar(64) COMMENT '密码',
  `userPayPwd` varchar(64) COMMENT '支付密码',
  `questionIndex` varchar(64) COMMENT '安全问题序号',
  `answer` varchar(255) COMMENT '答案',
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
