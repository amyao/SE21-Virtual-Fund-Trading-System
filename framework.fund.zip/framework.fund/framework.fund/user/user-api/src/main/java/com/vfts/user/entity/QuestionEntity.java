package com.vfts.user.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class QuestionEntity {
    int questionIndex;
    String answer;

    public QuestionEntity(int questionIndex, String answer) {
        this.questionIndex = questionIndex;
        this.answer = answer;
    }

    public int getQeustionIndex() {
        return questionIndex;
    }

    public void setQuestionIndex(int questionIndex) {
        this.questionIndex = questionIndex;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
}