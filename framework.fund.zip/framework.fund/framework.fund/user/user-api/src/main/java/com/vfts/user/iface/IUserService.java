package com.vfts.user.iface;

import com.vfts.user.entity.UserEntity;

public interface IUserService {
    /* Create User */
    void createUser(UserEntity userEntity);

    /* Update User Login Pwd or Payment Pwd */
    String updatePwd(UserEntity userEntity);
    String updatePayPwd(UserEntity userEntity);

    /* Delete User */
    void deleteUser(String uuid);

    /* Return User with uuid */
    UserEntity getUserByUuid(String uuid);

    /* Return User with Username */
    UserEntity getUserByUsername(String username);

    /* Return a List of UserEntity Objects */
    List<UserEntity> listAllUsers();

    /* Update Security Question */
    String updateSecurityQuestion(String uuid, QuestionEntity questionPair);

    /* Verify the Payment Pwd for userId */
    /* If input matches record, return 0; otherwise, return 1 */
    int checkPayPwd(String uuid, String payPwd);
}
