package com.vfts.user.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class UserEntity {
    private String uuid;
    private String username;
    private String pwd;
    private String payPwd;
    //private int questionIndex;
    //private String answer;

    public UserEntity(String uuid, String username, String pwd, String payPwd) {
        this.uuid = uuid;
        this.username = username;
        this.pwd = pwd;
        this.payPwd = payPwd;
        //this.questionIndex = questionIndex;
        //this.answer = answer;
    }

    public String getId() {
        return uuid;
    }

    public void setId(String id) {
        this.uuid = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getPayPwd() {
        return payPwd;
    }

    public void setPayPwd(String payPwd) {
        this.payPwd = payPwd;
    }

    @Override
    public String toString() {
        return "{" +
                "Username='" + getUsername() + "'" +
                "; Password='" + getPwd() + "'" +
                "}";
    }
}
